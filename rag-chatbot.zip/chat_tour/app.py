from langchain_google_genai import ChatGoogleGenerativeAI
from langchain.prompts import PromptTemplate
from langchain.chains.question_answering import load_qa_chain
from flask import Flask,request, jsonify
from langchain.vectorstores import FAISS
from langchain_google_genai import GoogleGenerativeAIEmbeddings
import os
from dotenv import load_dotenv



# Load environment variables
load_dotenv()
api_key = os.getenv("GOOGLE_API_KEY")
if not api_key:
    raise ValueError("Google API Key is not set in the environment variables.")

# Set up Google API key
os.environ["GOOGLE_API_KEY"] = api_key

def generate_answer(docs, user_question):
    # Extract relevant context from the documents
    context = "\n".join([doc.page_content for doc in docs])

    # Prompt template for generating an answer
    prompt_template = """
    Based on the user's question and the document context, provide a detailed and accurate answer.\n\n
    Document Context:\n {context}\n
    User Question: \n{question}\n

    Answer:
    """

    # Loading the model for generating the answer
    model = ChatGoogleGenerativeAI(model="gemini-1.5-pro-002", temperature=0.1)

    # Set up the prompt for generating the answer
    prompt = PromptTemplate(template=prompt_template, input_variables=["context", "question"])
    chain = load_qa_chain(model, chain_type="stuff", prompt=prompt)

    # Generate the answer
    answer = chain({"input_documents": docs, "question": user_question}, return_only_outputs=True)['output_text']
    return answer

google_embeddings = GoogleGenerativeAIEmbeddings(model="models/embedding-001")
vector_store = FAISS.load_local("vector_store", google_embeddings,allow_dangerous_deserialization=True)

app = Flask(__name__)
@app.route("/ask_question",methods=['POST'])
def get_answer():
    data = request.get_json()
    question = data.get('question')

    if not question:
        return jsonify({'error': 'Question is required'}), 400
    
    docs = vector_store.similarity_search(question)
    answer = generate_answer(docs,question)
    return jsonify({'answer': answer})

if __name__ == '__main__':
    app.run(host='127.0.0.1',port=6420)


import os
import faiss
import pickle
from langchain.document_loaders import PyPDFLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_google_genai import GoogleGenerativeAIEmbeddings
from langchain.vectorstores import FAISS
from dotenv import load_dotenv

load_dotenv()
api_key = os.getenv("GOOGLE_API_KEY")
if not api_key:
    raise ValueError("Google API Key is not set in the environment variables.")

# Set up Google API key
os.environ["GOOGLE_API_KEY"] = api_key

# Load the PDF
pdf_path =  "tntour.pdf"
loader = PyPDFLoader(pdf_path)
documents = loader.load()

# Split text into chunks
text_splitter = RecursiveCharacterTextSplitter(chunk_size=500, chunk_overlap=50)
docs = text_splitter.split_documents(documents)

# Initialize Google Embeddings
google_embeddings = GoogleGenerativeAIEmbeddings(model="models/embedding-001")

# Create FAISS vector store
vector_store = FAISS.from_documents(docs, google_embeddings)

# Save FAISS index and metadata
vector_store.save_local("vector_store")
